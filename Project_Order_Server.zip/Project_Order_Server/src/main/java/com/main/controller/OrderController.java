package com.main.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.main.feign.ProductFeign;
import com.main.model.Order;
import com.main.model.Product;
import com.main.service.OrderServiceIntf;

@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
	private OrderServiceIntf orderServiceIntf;
	@Autowired
	private ProductFeign productFeignClient;

	@PostMapping("/saveOrder")
	public ResponseEntity<String> saveRegister(@RequestBody Order reg1) {
		orderServiceIntf.saveOrderDetails(reg1);
		return new ResponseEntity<String>("Order Added Successfully", HttpStatus.CREATED);
	}

	@GetMapping("/fetchOrder")
	public ResponseEntity<List<Order>> fetchData() {
		List<Order> list = orderServiceIntf.fetchProductData();
		if (list.size() == 0) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@GetMapping("/fetchOrderId/{orderId}")
	public ResponseEntity<Optional<Order>> buyUsingId(@PathVariable("orderId") int orderId) {
		Optional<Order> option = orderServiceIntf.buyUsingOrderId(orderId);
		if (option.isPresent())
			return new ResponseEntity<>(option, HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@GetMapping("/getTotalAmount/{orderId}")
	public double getTotalAmount(@PathVariable("orderId") int orderId) {
		Order order = orderServiceIntf.buyUsingOrderId(orderId).get();
		Product product = productFeignClient.buyUsingId(order.getProductId()).getBody();
		double totalAmount = ((product.getProductPrice()) * (order.getQuantity()));
		System.out.println(totalAmount);
		return totalAmount;
	}

}

package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Invoice_Tbl")
public class Invoice {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int in_id;
	private int orderId;
	private float totalAmount;

	@Override
	public String toString() {
		return "Invoice [in_id=" + in_id + ", orderId=" + orderId + ", totalAmount=" + totalAmount + ", paymentStatus="
				+ paymentStatus + "]";
	}

	public Invoice(int orderId, float totalAmount, String paymentStatus) {
		super();
		this.orderId = orderId;
		this.totalAmount = totalAmount;
		this.paymentStatus = paymentStatus;
	}

	public int getIn_id() {
		return in_id;
	}

	public void setIn_id(int in_id) {
		this.in_id = in_id;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public float getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	private String paymentStatus;

	public Invoice() {
	}

}
